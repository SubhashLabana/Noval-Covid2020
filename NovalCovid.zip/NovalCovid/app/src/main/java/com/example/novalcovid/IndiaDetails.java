package com.example.novalcovid;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.leo.simplearcloader.SimpleArcLoader;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class IndiaDetails extends AppCompatActivity {

    EditText edtSearch;
    ListView listView;
    SimpleArcLoader loader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_india_details);

        edtSearch = findViewById(R.id.edtSerach);
        listView = findViewById(R.id.listView);
        loader = findViewById(R.id.loader);
        getSupportActionBar().setTitle("Affected State");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        fetchData();
    }

    private void fetchData() {

//        private void fetchData() {
//
//            String url = "https://covid-19india-api.herokuapp.com/v2.0/state_data";
//            loader.start();
//            StringRequest request = new StringRequest(Request.Method.GET, url,
//                    new Response.Listener<String>() {
//                        @Override
//                        public void onResponse(String response) {
//
//                            try {
//                                JSONArray jsonArray = new JSONArray(response);
//                                for (int i = 0; i < jsonArray.length(); i++) {
//
//                                    JSONObject jsonObject = jsonArray.getJSONObject(i);
//                                    String countryName = jsonObject.getString("state");
//                                    String cases = jsonObject.getString("confirmed");
//                                    String todayCases = jsonObject.getString("todayCases");
//                                    String deaths = jsonObject.getString("deaths");
//                                    String todayDeaths = jsonObject.getString("todayDeaths");
//                                    String recovered = jsonObject.getString("recovered");
//                                    String active = jsonObject.getString("active");
//                                    String critical = jsonObject.getString("critical");
//
//                                    JSONObject object = jsonObject.getJSONObject("countryInfo");
//                                    String flagUrl = object.getString("flag");
//
//                                    counteryModel = new CounteryModel(flagUrl, countryName, cases, todayCases, deaths, todayDeaths, recovered, active, critical);
//                                    counteryModelList.add(counteryModel);
//                                }
//
//                                myCustomAdapter = new MyCustomAdapter(AffectedCountries.this, counteryModelList);
//                                listView.setAdapter(myCustomAdapter);
//                                loader.stop();
//                                loader.setVisibility(View.GONE);
//
//
//                            } catch (JSONException e) {
//                                e.printStackTrace();
//                            }
//
//
//                        }
//                    }, new Response.ErrorListener() {
//                @Override
//                public void onErrorResponse(VolleyError error) {
//                    loader.stop();
//                    loader.setVisibility(View.GONE);
//                    Toast.makeText(AffectedCountries.this, error.getMessage(), Toast.LENGTH_SHORT).show();
//                }
//            });
//
//            RequestQueue requestQueue = Volley.newRequestQueue(this);
//            requestQueue.add(request);
//
//        }

    }
}
