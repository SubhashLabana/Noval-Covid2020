package com.example.novalcovid;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;

import com.leo.simplearcloader.SimpleArcLoader;

public class CountryDetail extends AppCompatActivity {

    private int positionCountry;
    TextView tvCountry,tvCases,tvRecovered,tvCritical,tvActive,tvTodaycases,tvTotalDeaths,tvTodayDeaths;
    SimpleArcLoader simpleArcLoader;
    ScrollView scrollView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country_detail);


        Intent intent = getIntent();
        positionCountry=intent.getIntExtra("position",0);

        getSupportActionBar().setTitle("Details of "+AffectedCountries.counteryModelList.get(positionCountry).getCountry());
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        tvCountry= findViewById(R.id.country);
        tvCases=findViewById(R.id.tvCases);
        tvRecovered=findViewById(R.id.tvRecovered);
        tvCritical=findViewById(R.id.tvCritical);
        tvActive=findViewById(R.id.tvActive);
        tvTodaycases=findViewById(R.id.tvTcases);
        tvTodayDeaths=findViewById(R.id.tvtodayDeaths);
        tvTotalDeaths=findViewById(R.id.tvTDeaths);
        simpleArcLoader = findViewById(R.id.loader);
        scrollView = findViewById(R.id.scrollStates);

        fetchData();








    }

    private void fetchData() {
        simpleArcLoader.start();
        tvCountry.setText(AffectedCountries.counteryModelList.get(positionCountry).getCountry());
        tvCases.setText(AffectedCountries.counteryModelList.get(positionCountry).getCases());
        tvRecovered.setText(AffectedCountries.counteryModelList.get(positionCountry).getRecovered());
        tvCritical.setText(AffectedCountries.counteryModelList.get(positionCountry).getCritical());
        tvActive.setText(AffectedCountries.counteryModelList.get(positionCountry).getActive());
        tvTodaycases.setText(AffectedCountries.counteryModelList.get(positionCountry).getTodayCases());
        tvTotalDeaths.setText(AffectedCountries.counteryModelList.get(positionCountry).getDeaths());
        tvTodayDeaths.setText(AffectedCountries.counteryModelList.get(positionCountry).getTodayDeaths());
        simpleArcLoader.stop();
        simpleArcLoader.setVisibility(View.GONE);
        scrollView.setVisibility(View.VISIBLE);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId()==android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);
    }
}
