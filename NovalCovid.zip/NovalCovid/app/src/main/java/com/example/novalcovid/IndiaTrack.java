package com.example.novalcovid;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class IndiaTrack extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ArrayList<CorornaItem> corornaItemArrayList;
    private  RecyclerviewAdapter recyclerviewAdapter;
    private RequestQueue requestQueue;
    TextView dailyDeths,dailyConfirm,dailyRecovered1,dateHeaders,totaldeath,totalConfirm,totalRecovered;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_india_track);

        dailyDeths=findViewById(R.id.dailyDeath);
        dailyConfirm=findViewById(R.id.dailyConfirmed);
        dailyRecovered1=findViewById(R.id.dailyRecovred);
        dateHeaders=findViewById(R.id.dataheader);
        totaldeath=findViewById(R.id.totaldeath);
        totalConfirm=findViewById(R.id.totalConfirm);
        totalRecovered=findViewById(R.id.totalRecovered);
        recyclerView=findViewById(R.id.myrecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerView.setAdapter(recyclerviewAdapter);

        recyclerView.setHasFixedSize(true);

        //recyclerView.setLayoutManager(new LinearLayoutManager(this));



        corornaItemArrayList=new ArrayList<>();
        requestQueue= Volley.newRequestQueue(this);
        jsonParse();




    }

    private void jsonParse() {
        String url="https://api.covid19india.org/raw_data.json";
        final JsonObjectRequest request = new
                JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray todayAndTotalDataArray=response.getJSONArray("stateWise");
                    JSONObject todayAndTotalDataJsonoObject =todayAndTotalDataArray.getJSONObject(0);

                    String dailyConfirmed=todayAndTotalDataJsonoObject.getString("deltaconfirmed");
                    String dailyDeath=todayAndTotalDataJsonoObject.getString("deltadeaths");
                    String dailyRecovered=todayAndTotalDataJsonoObject.getString("deltarecovered");
                    String dateHeader=todayAndTotalDataJsonoObject.getString("lastupdatedtime").substring(0,5);
                    dateHeader=getFormattedDate(dateHeader);
                    dailyConfirm.setText(dailyConfirmed);
                    dailyDeths.setText(dailyDeath);
                    dailyRecovered1.setText(dailyRecovered);
                    dateHeaders.setText(dateHeader);


                    String totalDeathFeatched = todayAndTotalDataJsonoObject.getString("deaths");
                    String totalRecoveredfetched=todayAndTotalDataJsonoObject.getString("recovered");
                    String totalConfirmedfetched = todayAndTotalDataJsonoObject.getString("confirmed");

                    totalConfirm.setText(totalConfirmedfetched);
                    totaldeath.setText(totalDeathFeatched);
                    totalRecovered.setText(totalRecoveredfetched);

                    for (int i=1; i<todayAndTotalDataArray.length();i++)
                    {
                        JSONObject statewiseArrayObject=todayAndTotalDataArray.getJSONObject(i);
                        String active=statewiseArrayObject.getString("active");
                        String death=statewiseArrayObject.getString("death");
                        String recovered=statewiseArrayObject.getString("recovered");
                        String state=statewiseArrayObject.getString("state");
                        String confirmed=statewiseArrayObject.getString("confirmed");
                        String lastUpdated=statewiseArrayObject.getString("lastupdatedtime");



                        String todayActive=statewiseArrayObject.getString("deltaconfirmed");
                        String todayDeath=statewiseArrayObject.getString("deltadeaths");
                        String todayRecovered=statewiseArrayObject.getString("deltarecovered");


                        CorornaItem corornaItem =new CorornaItem(state,death,active,recovered,confirmed,lastUpdated,todayDeath,todayRecovered,todayActive);
                        corornaItemArrayList.add(corornaItem);

                    }

                     recyclerviewAdapter = new RecyclerviewAdapter(IndiaTrack.this,corornaItemArrayList);





                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });



    }

    private String getFormattedDate(String dateHeader) {
        switch (dateHeader.substring(3,5)){
            case "01":
                return dateHeader.substring(0,2)+" Jan";
            case "02":
                return dateHeader.substring(0,2)+" Feb";
            case "03":
                return dateHeader.substring(0,2)+" Mar";
            case "04":
                return dateHeader.substring(0,2)+" Apr";
            case "05":
                return dateHeader.substring(0,2)+" May";
            case "06":
                return dateHeader.substring(0,2)+" Jun";
            case "07":
                return dateHeader.substring(0,2)+" Jul";
            case "08":
                return dateHeader.substring(0,2)+" Aug";
            case "09":
                return dateHeader.substring(0,2)+" Sep";
            case "10":
                return dateHeader.substring(0,2)+" Oct";
            case "11":
                return dateHeader.substring(0,2)+" Nov";
            case "12":
                return dateHeader.substring(0,2)+" Dec";
            default:
                return null;
        }
    }
}
