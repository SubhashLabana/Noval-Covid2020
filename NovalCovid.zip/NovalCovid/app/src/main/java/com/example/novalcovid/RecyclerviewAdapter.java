package com.example.novalcovid;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerviewAdapter extends RecyclerView.Adapter<RecyclerviewAdapter.Recyclerviewholder> {

    private Context context;
    private ArrayList<CorornaItem> corornaItemArrayList;

    public RecyclerviewAdapter(Context context, ArrayList<CorornaItem> corornaItemArrayList) {
        this.context = context;
        this.corornaItemArrayList = corornaItemArrayList;
    }

    @NonNull
    @Override
    public Recyclerviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.news_list,parent,false);
        return  new Recyclerviewholder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull Recyclerviewholder holder, int position) {

        CorornaItem corornaItem=corornaItemArrayList.get(position);
        String state=corornaItem.getState();
        String death=corornaItem.getDeath();
        String recovered=corornaItem.getRecovered();
        String active=corornaItem.getActive();
        String confirmed=corornaItem.getConfirmed();
        String lastupdated=corornaItem.getLastupdated();
        String todayDeath=corornaItem.getTodayDeath();
        String todayActive=corornaItem.getTodayActive();
        String todayrecovered=corornaItem.getTodayRecovered();

        holder.state.setText(state);
        holder.death.setText(death);
        holder.recovered.setText(recovered);
        holder.active.setText(active);
        holder.confirmed.setText(confirmed);
        holder.lastUpdated.setText(lastupdated);
        holder.todatDeath.setText(String.format("(%s)",todayDeath));
        holder.todayActive.setText(String.format("(%s)",todayActive));
        holder.todayrecovered.setText(String.format("(%s)",todayrecovered));
    }

    @Override
    public int getItemCount() {
        return corornaItemArrayList.size();
    }

    class Recyclerviewholder extends RecyclerView.ViewHolder{

        TextView state,death,recovered,active,confirmed,lastUpdated,todatDeath,todayActive,todayrecovered;

        public Recyclerviewholder(@NonNull View itemView) {
            super(itemView);
            death=itemView.findViewById(R.id.death);
            state=itemView.findViewById(R.id.state);
            recovered=itemView.findViewById(R.id.recovered);
            active=itemView.findViewById(R.id.active);
            confirmed=itemView.findViewById(R.id.confirmed);
            lastUpdated=itemView.findViewById(R.id.lastUpdated);
            todatDeath=itemView.findViewById(R.id.todayDeath);
            todayActive=itemView.findViewById(R.id.todayActive);
            todayrecovered=itemView.findViewById(R.id.todayRecovered);


        }
    }


}
